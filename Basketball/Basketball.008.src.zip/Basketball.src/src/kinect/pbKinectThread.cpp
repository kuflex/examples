#include "pbKinectThread.h"

pbKinectThread shared_kinectThread;