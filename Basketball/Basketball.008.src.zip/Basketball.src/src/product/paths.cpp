//---------------------------------------------------------------------------

//#include <vcl.h>
#pragma hdrstop

#include <windows.h>
#include <shlobj.h>

#include "product.h"

#include "paths.h"

//---------------------------------------------------------------------------

Paths sharedPaths;

//---------------------------------------------------------------------------
string getAppDataPath()
{
	string result = "";
	TCHAR szPath[MAX_PATH];

	if(SUCCEEDED(SHGetFolderPath(NULL,
							 CSIDL_COMMON_APPDATA|CSIDL_FLAG_CREATE,
							 //CSIDL_APPDATA
							 NULL,
							 0,
							 szPath)))
	{
        result = szPath;
	}

	return result;

}




//---------------------------------------------------------------------------
Paths::Paths()
{

}

void Paths::init( const string &binPath )
{
	_binPath = binPath; //ExtractFilePath( Application->ExeName ).c_str();
	_docPath 		= _binPath;

	string manufDir = getAppDataPath() + "\\" + PRODUCT_MANUFACTURER + "\\";
	_settingsPath 	= manufDir + PRODUCT_NAME + "\\"; 

	CreateDirectory( manufDir.c_str(), 0 );
	CreateDirectory( _settingsPath.c_str(), 0 );
}


//---------------------------------------------------------------------------
string Paths::binPath()			//���� � ����������� �������
{
	return _binPath;
}

//---------------------------------------------------------------------------
string Paths::settingsPath()		//���� � ����������
{
	return _settingsPath;
}

//---------------------------------------------------------------------------
string Paths::docPath()			//���� � ����������
{
	return _docPath;
}

//---------------------------------------------------------------------------
string Paths::gettingStartedFileName()	//quick start
{
	return docPath() + "GettingStarted.pdf";
}

//---------------------------------------------------------------------------
string Paths::siteUrl()			//����
{
	return PRODUCT_MANUF_URL;
}

//---------------------------------------------------------------------------
string Paths::supportUrl()		//������� �� �������� support
{
	return PRODUCT_SUPPORT_URL; //siteUrl() + "/support.html";        //TODO
}

//---------------------------------------------------------------------------
string Paths::buyUrl()			//�������� �������
{
	return PRODUCT_BUY_URL;
}

//---------------------------------------------------------------------------
string Paths::onlineHelpUrl()
{
	return PRODUCT_ONLINEHELP_URL;
}

//---------------------------------------------------------------------------
string Paths::defaultSettingsIniFile()
{
	return binPath() + "data/settings.ini";
}

//---------------------------------------------------------------------------
string Paths::userSettingsIniFile()
{
	return settingsPath() + "settings-user.ini";
}

//---------------------------------------------------------------------------
string Paths::runAppCommand()		//������� ��� ������� �������� ����������
{
	return binPath() + PRODUCT_EXE + ".exe";
}

//---------------------------------------------------------------------------

