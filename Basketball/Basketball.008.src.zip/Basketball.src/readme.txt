Floor-P

www.playbat.net	perevalovds@gmail.com	19.11.2010
--------------------------------

Written for OpenFrameworks 0.061 for Windows, 
at Microsoft Visual Studio Express C++ 2008.

For setting screen size and enabling full screen mode - change settings.ini.

--------------------------------

